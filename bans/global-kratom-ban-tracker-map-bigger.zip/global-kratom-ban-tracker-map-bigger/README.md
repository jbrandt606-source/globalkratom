Upload index.html to /bans/ and upload your hero image as /bans/highero.jpeg.

Included:
- Same topbar, brand navigation, analytics tags, fonts, favicon, and visual styling as the supplied Global Kratom page
- SEO title/description, canonical, Open Graph, Twitter cards, and schema.org structured data
- One interactive U.S. map only
- Mobile map enlarged to 800px inside a swipeable horizontal viewport
- State dropdown for mobile accessibility
- Searchable directory of 250 enumerated local jurisdictions across 17 states
- State-panel local-ban previews
- AntiKratom.org Action Center link
- No individual state-page links

Important data audit:
The workbook is internally inconsistent. Enumerated local-jurisdiction names total 250; parenthetical state totals sum to 249; final total says 251. This build uses the enumerated entries and discloses the discrepancy.
